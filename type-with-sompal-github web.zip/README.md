# Type With Sompal ✍️

A typing practice website created by **Aakash Saini** in memory of his father **Mr. Sompal Singh**.

## 🌟 Features
- Real-time WPM and Accuracy Calculation
- Strict word-by-word correctness
- Typing Games (Random sentences)
- Mobile Responsive Design
- Game Mode with one-click sentence loader

## 🚀 Live Preview
Once uploaded to GitHub Pages, your site will be accessible at:
`https://aakash0042.github.io/type-with-sompal`
